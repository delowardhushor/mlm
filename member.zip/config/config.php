<?php


define("DB_HOST", "sql207.epizy.com");
define("DB_USER", "epiz_21282006");
define("DB_PASS", "1GkylzSW89qA");
define("DB_NAME", "epiz_21282006_mlm");


// define("DB_HOST", "localhost");
// define("DB_USER", "root");
// define("DB_PASS", "");
// define("DB_NAME", "mlm");
?>
