<?php


// define("DB_HOST", "localhost");
// define("DB_USER", "root");
// define("DB_PASS", "");
// define("DB_NAME", "mlm");


define("DB_HOST", "localhost");
define("DB_USER", "sulovmarket");
define("DB_PASS", "@@Nazmul121");
define("DB_NAME", "sulovmarket_mlm");


?>
