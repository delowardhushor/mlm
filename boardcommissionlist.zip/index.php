<?php  

	//Header('Location:members.php');
	echo "<script>window.location ='members.php';</script>";

?>