<?php


define("DB_HOST", "localhost");
define("DB_USER", "id6762575_id6762575_dhushor");
define("DB_PASS", "delowar@4512");
define("DB_NAME", "id6762575_mlm");
?>
